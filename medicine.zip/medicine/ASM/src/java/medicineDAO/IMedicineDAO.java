/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package medicineDAO;

import java.sql.SQLException;
import java.util.List;
import model.Medicine;

/**
 *
 * @author ASUS
 */
public interface IMedicineDAO {

    List<Medicine> getAllMedicine() throws SQLException;

    public void insertMedicine(Medicine me) throws SQLException;

    public boolean updateProduct(Medicine pro) throws SQLException;

    public Medicine selectMedicine(int id);

    public boolean deleteProduct(int id) throws SQLException;
    
   List<Medicine> searchMedicineByName(String name) throws SQLException;

    
      void updateSalePrice(int id, double salePrice) throws SQLException;
}
