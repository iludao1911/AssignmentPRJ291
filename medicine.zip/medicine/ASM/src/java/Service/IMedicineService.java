/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Service;

import java.sql.SQLException;
import java.util.List;
import model.Medicine;

/**
 *
 * @author ASUS
 */
public interface IMedicineService {

    List<Medicine> ListMedicine() throws SQLException;

    void addMedicine(Medicine me) throws SQLException;

    public boolean editMedicine(Medicine me) throws SQLException;

    public Medicine getMedicineById(int id);

    boolean removeMedicine(int id) throws SQLException;

    List<Medicine> searchMedicineByName(String name) throws SQLException;

    void SalePrice(int id, double salePrice) throws SQLException;
}
