/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package medicineDAO;

import DAO.DBConnection;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Medicine;
import java.sql.Date;

/**
 *
 * @author ASUS
 */
public class MedicineDAO implements IMedicineDAO {

    private static final String UPDATE_SALE_PRICE = "UPDATE Medicine SET sale_price = ? WHERE medicine_id = ?";
    private static final String SEARCH_MEDICINE = "SELECT * FROM Medicine WHERE name LIKE ?";
    private static final String DELETE_MEDICINE = "DELETE FROM Medicine WHERE Medicine_id = ?";
    private static final String SELECT_ALL_MEDICIEN = "SELECT Medicine_id, name, description, price, quantity, category, expiry_date, image_path, sale_price FROM Medicine";
    private static final String INSERT_MEDICINE = "INSERT INTO Medicine (name, description, price, quantity, category, expiry_date, image_path) " + "VALUES (?, ?, ?, ?, ?, ?, ?)";
    private static final String UPDATE_MEDICINE = "UPDATE Medicine SET name=?, description=?, price=?, quantity=?, category=?, expiry_date=?, image_path=? WHERE medicine_id=?";
    private static final String GET_MEDICINE_BY_ID = "SELECT * FROM Medicine WHERE Medicine_id = ?";

    @Override

    public List<Medicine> getAllMedicine() throws SQLException {
        List<Medicine> me = new ArrayList<>();
        try (Connection con = DBConnection.getConnection()) {
            if (con != null) {
                PreparedStatement ps = con.prepareStatement(SELECT_ALL_MEDICIEN);
                System.out.println(ps);
                ResultSet rs = ps.executeQuery();

                while (rs.next()) {
                    int id = rs.getInt("Medicine_id");
                    String name = rs.getString("name");
                    double price = rs.getDouble("price");
                    String description = rs.getString("description");
                    int quantity = rs.getInt("quantity");
                    String category = rs.getString("category");
                    Date importDate = rs.getDate("expiry_date");
                    String image = rs.getString("image_path");
                    Double salePrice = rs.getDouble("sale_price");
                    if (rs.wasNull()) {
                        salePrice = null;
                    }
                    Medicine m = new Medicine(id, name, description, price, quantity, category, importDate);
                    m.setImagePath(image);
                    m.setSalePrice(salePrice);
                    me.add(m);
                }
                return me;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return me;
    }

    @Override
    public void insertMedicine(Medicine me) throws SQLException {
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(INSERT_MEDICINE)) {
            ps.setString(1, me.getName());
            ps.setString(2, me.getDescription());
            ps.setDouble(3, me.getPrice());
            ps.setInt(4, me.getQuantity());
            ps.setString(5, me.getCategory());
            ps.setDate(6, new java.sql.Date(me.getExpiryDate().getTime()));
            ps.setString(7, me.getImagePath());
            ps.executeUpdate();
        }
    }

    @Override
    public boolean updateProduct(Medicine pro) throws SQLException {
        boolean rowUpdated = false;
        try (Connection conn = DBConnection.getConnection()) {
            if (conn != null) {
                PreparedStatement ps = conn.prepareStatement(UPDATE_MEDICINE);
                ps.setNString(1, pro.getName());
                ps.setDouble(3, pro.getPrice());
                ps.setNString(2, pro.getDescription());
                ps.setInt(4, pro.getQuantity());
                ps.setNString(5, pro.getCategory());
                ps.setDate(6, (Date) pro.getExpiryDate());
                ps.setNString(7, pro.getImagePath());
                ps.setInt(8, pro.getMedicineId());
                int rowsUpdated = ps.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("User updated successfully!");
                } else {
                    System.out.println("No user found with the given ID!");
                }

            }

        }
        return rowUpdated;
    }

    @Override
    public Medicine selectMedicine(int id) {
        try (Connection conn = DBConnection.getConnection()) {
            if (conn != null) {
                PreparedStatement ps = conn.prepareStatement(GET_MEDICINE_BY_ID);
                ps.setInt(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        String name = rs.getNString("name");
                        double price = rs.getDouble("price");
                        String description = rs.getNString("description");
                        int quantity = rs.getInt("quantity");
                        String category = rs.getNString("category");
                        Date importDate = rs.getDate("expiry_date");
                        String image = rs.getNString("image_path");
                        Double salePrice = rs.getDouble("sale_price");
                        if (rs.wasNull()) {
                            salePrice = null;
                        }

                        Medicine m = new Medicine(id, name, description, price, quantity, category, importDate, image);
                        m.setSalePrice(salePrice); // thêm dòng này
                        return m;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean deleteProduct(int id) throws SQLException {
        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ptm = conn.prepareStatement(DELETE_MEDICINE);
            ptm.setInt(1, id);
            int check = ptm.executeUpdate();
            return check > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<Medicine> searchMedicineByName(String name) throws SQLException {
        List<Medicine> list = new ArrayList<>();
        String sql = "SELECT * FROM Medicine WHERE name LIKE ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "%" + name + "%");

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("Medicine_id");
                String mName = rs.getString("name");
                String description = rs.getString("description");
                double price = rs.getDouble("price");
                int quantity = rs.getInt("quantity");
                String category = rs.getString("category");
                Date expiryDate = rs.getDate("expiry_date");
                String imagePath = rs.getString("image_path");
                Double salePrice = rs.getDouble("sale_price");
                if (rs.wasNull()) {
                    salePrice = null;
                }

                Medicine m = new Medicine(id, mName, description, price, quantity, category, expiryDate);
                m.setImagePath(imagePath);
                m.setSalePrice(salePrice);
                list.add(m);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public void updateSalePrice(int id, double salePrice) throws SQLException {
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(UPDATE_SALE_PRICE)) {
            ps.setDouble(1, salePrice);
            ps.setInt(2, id);
            ps.executeUpdate();
        }
    }
}
