/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author ASUS
 */
public class Medicine {
    private int medicineId;
    private int supplierId;
    private String name;
    private String description;
    private double price;
    private int quantity;
    private String category;
    private Date expiryDate;
    private String imagePath;
    private Double salePrice;
    
    public Medicine() {
        
    }

    public Medicine(int medicineId, int supplierId, String name, String description, double price, int quantity, String category, Date expiryDate) {
        this.medicineId = medicineId;
        this.supplierId = supplierId;
        this.name = name;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
        this.category = category;
        this.expiryDate = expiryDate;
    }

    public Medicine(int medicineId, String name, String description, double price, int quantity, String category, Date expiryDate) {
        this.medicineId = medicineId;
        this.name = name;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
        this.category = category;
        this.expiryDate = expiryDate;
    }

    public Medicine(int medicineId, String name, String description, double price, int quantity, String category, Date expiryDate, String imagePath) {
        this.medicineId = medicineId;
        this.name = name;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
        this.category = category;
        this.expiryDate = expiryDate;
        this.imagePath = imagePath;
    }

    public Medicine(String name, String description, double price, int quantity, String category, Date expiryDate, String imagePath) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
        this.category = category;
        this.expiryDate = expiryDate;
        this.imagePath = imagePath;
    }

    
    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    
    public int getMedicineId() {
        return medicineId;
    }

    public void setMedicineId(int medicineId) {
        this.medicineId = medicineId;
    }

    public int getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    public Double getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(Double salePrice) {
        this.salePrice = salePrice;
    }
    
    @Override
    public String toString() {
        return "Medicine{" + "medicineId=" + medicineId + ", supplierId=" + supplierId + ", name=" + name + ", description=" + description + ", price=" + price + ", quantity=" + quantity + ", category=" + category + ", expiryDate=" + expiryDate + '}';
    }
    
    
}
