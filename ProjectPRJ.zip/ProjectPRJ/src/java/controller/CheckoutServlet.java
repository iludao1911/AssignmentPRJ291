/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.*;
import model.CartItem;
import model.Customer;

@WebServlet("/checkout")
public class CheckoutServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        Customer customer = (Customer) session.getAttribute("currentCustomer");

        if (customer == null) {
            response.sendRedirect("customer-login.jsp");
            return;
        }

        @SuppressWarnings("unchecked")
        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");

        if (cart == null || cart.isEmpty()) {
            request.setAttribute("message", "Giỏ hàng của bạn đang trống!");
            request.getRequestDispatcher("cart-view.jsp").forward(request, response);
            return;
        }

        // Tính tổng tiền và tổng số lượng
        double totalAmount = 0;
        int totalQuantity = 0;
        for (CartItem item : cart) {
            totalAmount += item.getMedicine().getPrice().doubleValue() * item.getQuantity();
            totalQuantity += item.getQuantity();
        }

        // Gửi thông tin sang trang hiển thị hóa đơn
        request.setAttribute("customer", customer);
        request.setAttribute("cart", cart);
        request.setAttribute("totalAmount", totalAmount);
        request.setAttribute("totalQuantity", totalQuantity);

        // Xóa giỏ hàng sau khi thanh toán xong
        session.removeAttribute("cart");

        request.getRequestDispatcher("checkout-success.jsp").forward(request, response);
    }
}
