/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import Service.MedicineService;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import java.io.File;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.List;
import model.Medicine;
import java.sql.Date;

/**
 *
 * @author ASUS
 */
@MultipartConfig(
        fileSizeThreshold = 1024 * 1024 * 2, // 2MB
        maxFileSize = 1024 * 1024 * 10, // 10MB
        maxRequestSize = 1024 * 1024 * 50 // 50MB
)

@WebServlet(name = "MedicineServlet", urlPatterns = {"/medicine"})
public class MedicineServlet extends HttpServlet {

    private MedicineService medicineService;

    public void init() {
        medicineService = new MedicineService();
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet MedicineServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet MedicineServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "";
        }
        try {
            switch (action) {
                case "create":
                    ShowNewForm(request, response);
                    break;
                case "edit":
                    ShowEditForm(request, response);
                    break;
                case "delete":
                    ShowDeleteForm(request, response);
                    break;
                case "searchName":
                    searchMedicineByName(request, response);
                    break;
                case "sale":  // Hiển thị form giảm giá
                    showSaleForm(request, response);
                    break;
                default:
                    listMedicine(request, response);
                    break;
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "";
        }
        try {
            switch (action) {
                case "create":
                    insertMedicine(request, response);
                    break;
                case "delete":
                    deleteMedicine(request, response);
                    break;
                case "edit":
                    updateMedicine(request, response);
                    break;
                case "sale":  // Lưu giá sale
                    applySale(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void listMedicine(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
        List<Medicine> list = medicineService.ListMedicine();
        request.setAttribute("listMedicine", list);
        RequestDispatcher dispatcher = request.getRequestDispatcher("medicine/ListMedicine.jsp");
        dispatcher.forward(request, response);
    }

    private void ShowNewForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("medicine/createMedicine.jsp");
        dispatcher.forward(request, response);
    }

    private void ShowEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Medicine existingProduct = medicineService.getMedicineById(id);
        RequestDispatcher dispatcher = request.getRequestDispatcher("medicine/editMedicine.jsp");
        request.setAttribute("medicine", existingProduct);
        dispatcher.forward(request, response);
    }

    private void ShowDeleteForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Medicine existingProduct = medicineService.getMedicineById(id);
        RequestDispatcher dispatcher = request.getRequestDispatcher("medicine/deleteMedicine.jsp");
        request.setAttribute("medicine", existingProduct);
        dispatcher.forward(request, response);
    }

    private void insertMedicine(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {

        try {
            // 🧾 Lấy dữ liệu từ form (bỏ medicineId)
            //    int supplierId = Integer.parseInt(request.getParameter("supplierId"));
            String name = request.getParameter("name");
            String description = request.getParameter("description");
            double price = Double.parseDouble(request.getParameter("price"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            String category = request.getParameter("category");
            Date expiryDate = Date.valueOf(request.getParameter("expiryDate")); // java.sql.Date

            // 📷 Lấy file ảnh upload
            Part filePart = request.getPart("image_path");
            String fileName = null;

            if (filePart != null && filePart.getSize() > 0) {
                fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
                String uploadPath = getServletContext().getRealPath("/image");
                File uploadDir = new File(uploadPath);
                if (!uploadDir.exists()) {
                    uploadDir.mkdirs();
                }
                filePart.write(uploadPath + File.separator + fileName);
            }

// Nếu không upload ảnh, gán ảnh mặc định
            if (fileName == null || fileName.isEmpty()) {
                fileName = "no-image.png";
            }

// 🧩 Tạo đối tượng và lưu tên file (chỉ tên file, không có đường dẫn)
            Medicine newMe = new Medicine(name, description, price, quantity, category, expiryDate, fileName);
            newMe.setImagePath(fileName);
            medicineService.addMedicine(newMe);
            response.sendRedirect(request.getContextPath() + "/medicine");

        } catch (NumberFormatException e) {
            request.setAttribute("errorMsg", "Giá trị số không hợp lệ!");
            request.getRequestDispatcher("medicine/createMedicine.jsp").forward(request, response);
        } catch (IllegalArgumentException e) {
            request.setAttribute("errorMsg", "Ngày hết hạn không hợp lệ!");
            request.getRequestDispatcher("medicine/createMedicine.jsp").forward(request, response);
        }
    }

    private void deleteMedicine(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        medicineService.removeMedicine(id);
        List<Medicine> listMedicine = medicineService.ListMedicine();
        request.setAttribute("listMedicine", listMedicine); // ✅ đúng tên
        RequestDispatcher dispatcher
                = request.getRequestDispatcher("medicine/ListMedicine.jsp");
        dispatcher.forward(request, response);
    }

    private void updateMedicine(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            String name = request.getParameter("name");
            String description = request.getParameter("description");
            double price = Double.parseDouble(request.getParameter("price"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            String category = request.getParameter("category");
            Date expiryDate = Date.valueOf(request.getParameter("expiry_date"));

            // 📂 Xử lý file ảnh (nếu có)
            Part filePart = request.getPart("image_path");
            String fileName = null;

            if (filePart != null && filePart.getSize() > 0) {
                fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
                String uploadPath = getServletContext().getRealPath("/image");
                File uploadDir = new File(uploadPath);
                if (!uploadDir.exists()) {
                    uploadDir.mkdirs();
                }
                filePart.write(uploadPath + File.separator + fileName);
            } else {
                // 🔁 Giữ lại ảnh cũ nếu không upload ảnh mới
                fileName = medicineService.getMedicineById(id).getImagePath();
            }

            // 🧩 Tạo đối tượng cập nhật
            Medicine updatedMedicine = new Medicine(id, name, description, price, quantity, category, expiryDate, fileName);
            updatedMedicine.setImagePath(fileName);

            medicineService.editMedicine(updatedMedicine);

            // ✅ Quay về danh sách
            response.sendRedirect(request.getContextPath() + "/medicine");

        } catch (NumberFormatException e) {
            request.setAttribute("error", "Giá trị không hợp lệ!");
            request.getRequestDispatcher("medicine/editMedicine.jsp").forward(request, response);
        }
    }

    private void searchMedicineByName(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
        String name = request.getParameter("name");
        List<Medicine> list = medicineService.searchMedicineByName(name);
        request.setAttribute("listMedicine", list);

        RequestDispatcher dispatcher = request.getRequestDispatcher("medicine/ListMedicine.jsp");
        dispatcher.forward(request, response);
    }

    private void showSaleForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         int id = Integer.parseInt(request.getParameter("id"));
    Medicine medicine = medicineService.getMedicineById(id);
    request.setAttribute("medicine", medicine);
    RequestDispatcher dispatcher = request.getRequestDispatcher("medicine/saleMedicine.jsp");
    dispatcher.forward(request, response);
    }

    private void applySale(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
          try {
        int id = Integer.parseInt(request.getParameter("id")); // phải khớp với hidden name="id"
        double salePercent = Double.parseDouble(request.getParameter("salePercent"));

        medicineService.SalePrice(id, salePercent);

        response.sendRedirect(request.getContextPath() + "/medicine");
    } catch (NumberFormatException e) {
        request.setAttribute("error", "Giá trị % giảm không hợp lệ!");
        showSaleForm(request, response);
    }
}
}
