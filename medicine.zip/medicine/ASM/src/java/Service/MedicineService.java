/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import java.sql.SQLException;
import java.util.List;
import medicineDAO.IMedicineDAO;
import medicineDAO.MedicineDAO;
import model.Medicine;

/**
 *
 * @author ASUS
 */
public class MedicineService implements IMedicineService {

    private IMedicineDAO medicineDao;

    public MedicineService() {
        this.medicineDao = new MedicineDAO();
    }

    @Override
    public List<Medicine> ListMedicine() throws SQLException {
        return medicineDao.getAllMedicine();
    }

    @Override
    public void addMedicine(Medicine me) throws SQLException {
        if (me.getName() == null || me.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Tên sản phẩm không được để trống");
        }

        if (me.getPrice() <= 0) {
            throw new IllegalArgumentException("Giá sản phẩm phải lớn hơn 0");
        }
        medicineDao.insertMedicine(me);
    }

    @Override
    public boolean editMedicine(Medicine me) throws SQLException {
        return medicineDao.updateProduct(me);
    }

    @Override
    public Medicine getMedicineById(int id) {
        return medicineDao.selectMedicine(id);
    }

    @Override
    public boolean removeMedicine(int id) throws SQLException {
        return medicineDao.deleteProduct(id);
    }

    @Override
    public List<Medicine> searchMedicineByName(String name) throws SQLException {
       return medicineDao.searchMedicineByName(name);
    }

    @Override
    public void SalePrice(int id, double salePrice) throws SQLException {
        Medicine m = medicineDao.selectMedicine(id);
        if (m != null) {
            double newPrice = m.getPrice() * (1 - salePrice / 100.0);
            medicineDao.updateSalePrice(id, newPrice);
        } else {
            throw new IllegalArgumentException("Không tìm thấy thuốc với ID: " + id);
        }
    }

}
