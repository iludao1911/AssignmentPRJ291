/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.*;
import java.util.List;
import model.*;
import dao.DBConnection;

public class OrderDAO {
    public int createOrder(Order order) throws SQLException {
        String sql = "INSERT INTO Orders (customer_id, total_amount) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, order.getCustomerId());
            stmt.setBigDecimal(2, order.getTotalAmount());
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) return rs.getInt(1);
        }
        return -1;
    }

    public void addOrderDetails(int orderId, List<CartItem> cartItems) throws SQLException {
        String sql = "INSERT INTO OrderDetails (order_id, medicine_id, quantity, price) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            for (CartItem item : cartItems) {
                stmt.setInt(1, orderId);
                stmt.setInt(2, item.getMedicine().getMedicineId());
                stmt.setInt(3, item.getQuantity());
                stmt.setBigDecimal(4, item.getMedicine().getPrice());
                stmt.addBatch();
            }
            stmt.executeBatch();
        }
    }
}

